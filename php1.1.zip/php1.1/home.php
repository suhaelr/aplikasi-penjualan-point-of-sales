 <!--sidebar end-->
      
      <!-- **********************************************************************************************************************************************************
      MAIN CONTENT
      *********************************************************************************************************************************************************** -->
      <!--main content start-->
      <section id="main-content">
          <section class="wrapper">

		  <head>
				<link rel="stylesheet" href="styles.css"> 
		  </head>

	<body>
	
		<canvas id="game" height="200" width="1000"></canvas>
		<p class="controls">Tekan Spasi Untuk Memulai dan Loncat. Refresh Laman Untuk Memulai Kembali </p>

        <script src="js/helpers.js"></script>
        <script src="js/objects/game-object.js"></script>
        <script src="js/objects/cactus.js"></script>
        <script src="js/objects/dinosaur.js"></script>
        <script src="js/objects/background.js"></script>
        <script src="js/objects/score.js"></script>
        <script src="js/game.js"></script>
        <script>
        	new Game({
        		el: document.getElementById("game")
        	});
        </script>
	</body>
			
  </section>

